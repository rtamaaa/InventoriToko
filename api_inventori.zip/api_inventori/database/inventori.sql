-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 25 Jul 2025 pada 16.59
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventori`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `stock` int(11) NOT NULL,
  `price` double NOT NULL,
  `image_url` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `products`
--

INSERT INTO `products` (`id`, `name`, `stock`, `price`, `image_url`) VALUES
(1, 'Smartphone Samsung Galaxy A14', 50, 2500000, ''),
(2, 'Smartphone Xiaomi Redmi Note 12', 40, 2200000, ''),
(3, 'Laptop ASUS Vivobook 14', 30, 7500000, ''),
(4, 'Laptop Lenovo IdeaPad Slim 3', 25, 6800000, ''),
(5, 'Headphone JBL Tune 500BT', 60, 650000, ''),
(6, 'Earbuds Xiaomi Mi True Wireless', 70, 400000, ''),
(7, 'Smartwatch Huawei Band 7', 45, 700000, ''),
(8, 'Keyboard Logitech K380', 55, 400000, ''),
(9, 'Mouse Logitech M220', 80, 200000, ''),
(10, 'Speaker Bluetooth Anker Soundcore', 35, 900000, ''),
(11, 'Powerbank Anker 10000mAh', 100, 350000, ''),
(12, 'Flashdisk Sandisk 32GB', 120, 90000, ''),
(13, 'Harddisk Eksternal Seagate 1TB', 40, 750000, ''),
(14, 'Monitor Samsung 24 Inch', 20, 1500000, ''),
(15, 'Printer Canon PIXMA MG2570S', 15, 800000, ''),
(16, 'Router TP-Link TL-WR840N', 50, 250000, ''),
(17, 'Kamera Canon EOS M50', 10, 9000000, ''),
(18, 'Tripod Kamera Takara ECO-173A', 35, 200000, ''),
(19, 'Smart TV Xiaomi 43 Inch', 8, 4500000, ''),
(20, 'Tablet Samsung Galaxy Tab A8', 12, 3000000, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(1, 'admin', 'admin@gmail.com', '$2y$10$CzZdBxuJDYWk6Mzn4HoNi.ZDt4nx49a8HY9fb2.avNDgrUsdHBhSG');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
