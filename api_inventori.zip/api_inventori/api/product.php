<?php
include '../config/config.php';

header("Content-Type: application/json");

$sql = "SELECT * FROM products";
$result = $conn->query($sql);

$products = [];

while ($row = $result->fetch_assoc()) {
    // Tambahkan default placeholder kalau kosong
    if (empty($row['imageUrl'])) {
        $row['imageUrl'] = "https://cdn.pixabay.com/photo/2017/07/14/07/44/strawberries-2502961_1280.jpg";
    }
    $products[] = $row;
}

echo json_encode([
    "success"  => true,
    "products" => $products
]);
?>
