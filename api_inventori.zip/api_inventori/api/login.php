<?php
include '../config/config.php';

header("Content-Type: application/json");

// Ambil dari POST, bukan raw JSON
$email    = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        echo json_encode([
            "success" => true,
            "message" => "Login berhasil!",
            "user"    => [
                "id"    => $row['id'],
                "name"  => $row['name'],
                "email" => $row['email']
            ]
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Password salah!"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "User tidak ditemukan!"]);
}
?>
